//this script holds http requests for neoj4 data

function __get_customer_relationships(customer_Number, url, clientId, authorization){
	return axios.get(url,
	{
		params: {
			customerNumber: customer_Number
		  },
        headers: { 
			'Accept':'application/json',
			'Content-Type':'application/json',
			'X-IBM-Client-Id': clientId,
			'Authorization': authorization
		}		
    }
	);
	//.then(response => {
      //  console.log(response);
        //return response;
    //});	
}



const Requests = {
    getCustomerRelationships: __get_customer_relationships
}