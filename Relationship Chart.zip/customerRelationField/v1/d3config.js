//This script holds constants & functions to make main script more readable
function __init_svg() {
    let graphSvg = d3.select("body")
        .append("div").attr("id", "graph-container")
        .append("svg").attr("id", "graph-svg");

    __update_svg_size();
    D3C['zoom'] = __create_zoom();

    graphSvg
        .attr("width", D3C.WIDTH)
        .attr("height", D3C.HEIGHT)
        .attr("preserveAspectRatio", "none")
        .call(D3C.zoom)
        .on("dblclick.zoom", null);

    __init_defs(graphSvg);

    //add groups for nodes & links
    graphSvg.append("g").classed("links", true);
    graphSvg.append("g").classed("nodes", true);

    //init legend
    const legendContainer = d3.select("body").append("div").attr("id", "legend-container");
    legendContainer.append("h2").text("Legend");

    const legendSvg = legendContainer.append("svg").attr("id", "legend-svg");
    legendSvg.append("g").attr("id", "legend")

    //init node info div
    d3.select("body").append("div").attr("id", "node-info");

    __init_simulation();
}

function __init_defs(graphSvg) {
    let defs = graphSvg.append("svg:defs");
    
    //define arrow for link lines
    defs.append("svg:marker")
        .attr("id", "triangle")
        .attr("refX", 0)
        .attr("refY", 2)
        .attr("markerWidth", 10)
        .attr("markerHeight", 10)
        .attr("orient", "auto")
        .append("path")
        .attr("d", "M0,0 L0,4 L" + D3C.TRIANGLE_HEIGHT + ",2 z")
        .attr("fill", "#999")
        .attr("stroke-width", 0) //FOR IE SUPPORT
        .attr("opacity", 0.6);

    //init background for link text
    let filter = defs.append("svg:filter")
        .attr("id", "solid")
        .attr("x", 0)
        .attr("y", 0)
        .attr("width", 1)
        .attr("height", 1);

    filter.append("feFlood").attr("flood-color", "white");

    let filterMerge = filter.append("feMerge");
    filterMerge.append("feMergeNode")
        .attr("in", "txtBackground")
    filterMerge.append("feMergeNode")
        .attr("in", "SourceGraphic")
}

function __init_graph(nodes) {
    __init_colors(nodes);
    __init_legend(nodes);
}

//create colour set for ndoes using node.labels
function __init_colors(nodes) {
    let domain = ['Customer-Person', 'Customer-Company', 'Product', 'Address', 'Telephone', 'Email', 'ControllerCRN' ];
    //d3.scaleOrdinal(['#000000', "#111111", "#222222", "#333333" ]); //define your own color scheme
    D3C.colorScale = d3.scaleOrdinal(d3.schemeTableau10).domain(domain);
}

function __init_simulation() {
    D3C.simulation = d3.forceSimulation()
        .force("charge", d3.forceManyBody().strength(-8000))
        .force("center", d3.forceCenter(D3C.WIDTH / 2, D3C.HEIGHT / 2))
        .force("x", d3.forceX(D3C.WIDTH / 2).strength(1))
        .force("y", d3.forceY(D3C.HEIGHT / 2).strength(1))
        .force("link", d3.forceLink().id(link => link.id).distance(200).strength(1))
        .on("tick", __tick);
}

function __init_legend(nodes) {
    //gets an array of unique labels
    const keys = [...new Set(nodes.map(n => n.labels.join('-')))];

    d3.select("#legend")
        .selectAll("g")
        .data(keys)
        .join(
            enter => {
                const keyDiv = enter.append("g").attr("class", "label-key");
                keyDiv.append("circle")
                    .attr("fill", D3C.colorScale)
                    .attr("r", 10)
                    .attr("cx", 10)
                    .attr("cy", (d, i) => 10 + i * 25);
            
                keyDiv.append("text")
                    .text((d) => {
                        if(d.includes('Customer')) {
                            if(d.includes('Person')) return "Personal Customer";
                            else return "Impersonal Customer";
                        }    
                        return d;
                    })
                    .attr("x", 25)
                    .attr("y", (d, i) => 17 + i * 25)

            },
            update => null,
            exit => exit.remove());
}

//apply phsyics with new nodes & links
function __update_simulation(nodes, links) {
    D3C.simulation
        .nodes(nodes)
        .force("link").links(links)
    //restart simulation with new data (alpha is used internally & decreases overtime, eventually stopping ticks until drag event)
    D3C.simulation.alpha(0.1).restart(); 
}

//set svg size to containers size
function __update_svg_size() {
    const bounds = d3.select("#graph-container").node().getBoundingClientRect();
    D3C.WIDTH = bounds.width;
    D3C.HEIGHT = bounds.height;
}

function __create_zoom() {
    return d3.zoom()
        .scaleExtent([.1, 4])
        //locks svg movement to bounds
        // .translateExtent([[0, 0], [D3C.WIDTH, D3C.HEIGHT]])
        .wheelDelta(() => -d3.event.deltaY * (d3.event.deltaMode ? 120 : 1) / 700)
        .on("zoom", () => {
            d3.select(".nodes").attr("transform", d3.event.transform);  
            d3.select(".links").attr("transform", d3.event.transform);
        });
}

//update nodes & links position
function __tick() {
    d3.selectAll(".link line")
        .attr("x1", link => link.source.x)
        .attr("y1", link => link.source.y)
        .attr("x2", link => __get_target_link_pos_x(link))
        .attr("y2", link => __get_target_link_pos_y(link));
    
    d3.selectAll(".link text")
        .attr("transform", link => __get_link_text_transform(link));
    
    d3.selectAll(".node circle")
        .attr("cx", node => node.x)
        .attr("cy", node => node.y);
    
    d3.selectAll(".node text")
        .attr("x", node => node.x)
        .attr("y", node => node.y + D3C.NODE_TEXT_SIZE / 3);
}

//get reduced X coodinate of link (target side) to fit arrow on the end
function __get_target_link_pos_x(link) {
    let lineReduction = __get_node_radius(link.target) + D3C.ARROW_DIST_FROM_TARGET * D3C.LINE_WIDTH;
    let angle = Math.atan((link.target.y - link.source.y) / (link.target.x - link.source.x));
    if(link.source.x > link.target.x) {
        return link.target.x + lineReduction * Math.cos(angle);
    }
    return link.target.x - lineReduction * Math.cos(angle);
}

//get reduced Y coodinate of link (target side) to fit arrow on the end
function __get_target_link_pos_y(link) {
    let lineReduction = __get_node_radius(link.target) + D3C.ARROW_DIST_FROM_TARGET * D3C.LINE_WIDTH;
    let angle = Math.atan((link.target.y - link.source.y) / (link.target.x - link.source.x));
    if(link.source.x > link.target.x) {
        angle = Math.atan((link.target.y - link.source.y) / (link.source.x - link.target.x))
    }
    return link.target.y - lineReduction * Math.sin(angle);
}

//position text in center of link & matches link's angle
function __get_link_text_transform(link) {
    let angle = Math.atan((link.target.y - link.source.y) / (link.target.x - link.source.x));
    let tx = (link.target.x + link.source.x) / 2;
    let ty = (link.target.y + link.source.y) / 2;
    return "translate(" + [tx, ty] + ") rotate(" + (angle * (180 / Math.PI)) + ")";
}

//handle node dragging
function __drag(simulation) {
    return d3.drag()
        .on("start", node => {
            if (!d3.event.active) simulation.alphaTarget(0.3).restart();
            node.fx = node.x;
            node.fy = node.y;
        })
        .on("drag", node => {
            node.fx += d3.event.dx;
            node.fy += d3.event.dy;
        })
        .on("end", node => {
            if (!d3.event.active) simulation.alphaTarget(0);
            node.fx = null;
            node.fy = null;

            //for freezing node in place
            // node.fixed = true;
            // node.fx += d3.event.dx;
            // node.fy += d3.event.dy;
        });
}

//get node by id
function __get_node(nodes, id) {
    for(let i = 0; i < nodes.length; i++){
        if(nodes[i].id === id) return nodes[i];
    }
}

//get prefered node text from PRIPERTIES_LIST
function __get_node_text(node) {
    for(let key in node.properties) {
        if(D3C.PROPERTIES_LIST.includes(key)) {
            return node.properties[key];
        }
    }
    
    //get default text
    for(let key in node.properties) {
        return node.properties[key];
    }
}

function __get_node_radius(node) {
    return node.root ? D3C.ROOT_NODE_RADIUS : D3C.DEFAULT_NODE_RADIUS;
}

const __triangle_height = 6;
const D3C = {
    DEFAULT_NODE_RADIUS:    20,
    ROOT_NODE_RADIUS:       25,
    LINE_WIDTH:             2,
    ARROW_DIST_FROM_TARGET: __triangle_height + 1,
    TRIANGLE_HEIGHT:        __triangle_height,
    NODE_TEXT_SIZE:         12,
    LINK_TEXT_SIZE:         9,
    PROPERTIES_LIST:        ["customerID","productDescription","Full_Name", "Company_Name", "Postcode",  "ControllerCRN"],
    initSvg:                __init_svg,
    initGraph:              __init_graph,
    updateSimulation:       __update_simulation,
    drag:                   __drag,
    getNode:                __get_node,
    getNodeText:            __get_node_text,
    getNodeRadius:          __get_node_radius
}