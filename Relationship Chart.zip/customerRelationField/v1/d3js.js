 let data = {
    nodes: [],
     rels: []
 }
//let data;
let rootId;
let initialLevel;
let expandLevel;
var customer_Number, url, clientId, authorization;
var isProduct;

//setup dom & physics
D3C.initSvg();

// for Appain
Appian.Component.onNewValue(newValues => {
    customer_Number = newValues.customerNumber;
    url = newValues.url;
    clientId = newValues.clientId;
    authorization = newValues.authorization;
    initialLevel = newValues.initialLevel;
    expandLevel = newValues.expandLevel;
	isProduct=newValues.isProduct;
	if(customer_Number===null|| customer_Number===''){
		return Appian.Component.setValidations("Customer number cannot be null")
	}
	if(url===null|| url===''){
		return Appian.Component.setValidations("url cannot be null")
	}
	else if(clientId===null|| clientId===''){
		return Appian.Component.setValidations("clientId cannot be null")
	}
	else if(authorization===null|| authorization===''){
		return Appian.Component.setValidations("authorization cannot be null")
	}
	else if(initialLevel===null|| initialLevel===''){
		return Appian.Component.setValidations("initialLevel cannot be null")
	}
	else if(expandLevel===null|| expandLevel===''){
		return Appian.Component.setValidations("expandLevel cannot be null")
	}
	else {
		Appian.Component.setValidations()
	}
    Requests.getCustomerRelationships(customer_Number, url, clientId, authorization).then(response => {
		if(response.status === 200) {
			initializeGraphData(response.data, customer_Number);
		}
		else
		{
			return Appian.Component.SetValidations("There has been some error retrieving the data. please refresh the page. If problem persists, contact your administrator")
		}
	})
	.catch(error=> {
		console.log(error.message);
		return Appian.Component.setValidations("There has been some error retrieving the data. please refresh the page. If problem persists, contact your administrator")
	});        
});

function initializeGraphData(graphData, customerNumber) {
    let rootNode = graphData.nodes.filter(node => node.properties.customerID === customerNumber)[0];
    rootNode.root = true;
    rootId = rootNode.id;

    mergeDataWithGraph(graphData, rootNode, initialLevel);
    updateGraph();
}

function mergeDataWithGraph(graphData, rootNode, expandLevels) {
    //filter nodes & links that already exist in "data"
    graphData = filterExistingData(graphData);
    if(graphData.nodes.length === 0 && graphData.rels.length === 0) return false;
    
    //inital values for links
    graphData.rels.forEach(link => {
        link.id = link.startNode + ':' + link.endNode;
        
        link.source = D3C.getNode(graphData.nodes, link.startNode);
        if(link.source === undefined) link.source = D3C.getNode(data.nodes, link.startNode);

        link.target = D3C.getNode(graphData.nodes, link.endNode);
        if(link.target === undefined) link.target = D3C.getNode(data.nodes, link.endNode);

        link.collapsed = false;
        link.collapsable = true;
    });
    
    //collapse all but level 1 around root node
    let hasExpandedNodes = initialCollapse(graphData, rootNode, expandLevels);

    //merge graphData with data
    data.nodes = data.nodes.concat(graphData.nodes);
    data.rels = data.rels.concat(graphData.rels);
    
    //setup svg, physics, & legend
    D3C.initGraph(data.nodes);
    return hasExpandedNodes;
}

function updateGraph() {
    //get nodes & links that arent collapsed
    let nodeIds = new Set();
    data.rels.forEach(link => {
        if(!link.collapsed) {
            nodeIds.add(link.source.id);
            nodeIds.add(link.target.id);
        }
    });
    let nodes = data.nodes.filter(node => nodeIds.has(node.id));
    let links = data.rels.filter(link => !link.collapsed); 
		
    //apply physics to new node & link data
    D3C.updateSimulation(nodes, links);

    //apply new links & remove old links based on ids
    d3.select(".links")
        .selectAll(".link")
        .data(links, link => link.id)
        .join(
            enter  => createLink(enter),
            update => null,
            exit   => exit.remove());

    //apply new nodes & remove old nodes based on ids
    d3.select(".nodes")
        .selectAll(".node")
        .data(nodes, node => node.id)
        .join(
            enter  => createNode(enter),
            update => null,
            exit   => exit.remove());
}

function createNode(root) {
    //create group for circle & text
    let nodeGroup = root.append("g")
        .classed("node", true);

    //create circle
    nodeGroup.append("circle")
        .attr("stroke-width",node => node.root ? 3.0 : 0.5)
        .attr("stroke", node => node.root ? "black" : undefined)
        .attr("r", D3C.getNodeRadius)
        .attr("fill", node => {
            
            let col =  D3C.colorScale(node.labels.join('-'));
            return node.root ? "#ffffff" : col; })
        .on("click", nodeClick)
        .on("mouseover", populateNodeInfo)
        .on("mouseout", depopulateNodeInfo)
        .call(D3C.drag(D3C.simulation))
       
    //create text
    nodeGroup.append("text")
        .classed("nodeText", true)
        .attr("stroke", "black")
        .attr("stroke-width", 0.5)
        .attr("text-anchor", "middle")
        .attr("font-size", D3C.NODE_TEXT_SIZE + "px")
        .text(D3C.getNodeText);
}

function createLink(root) {
    //create group for line & text
    let linkGroup = root.append("g")
        .classed("link", true);

    //create line
    linkGroup.append("line")
        .attr("stroke", "#999")
        .attr("stroke-opacity", 0.6)
        .attr("stroke-width", D3C.LINE_WIDTH)
        .attr("marker-end", "url(#triangle)");

    //create text
    linkGroup.append("text")
        .classed("linkText", true)
        .attr("fill", "black")
        .attr("stroke","black")
        .attr("stroke-width", 0.8)
        .attr("dy", 4)
        .attr("filter", "url(#solid)")
        .attr("text-anchor", "middle")
        .attr("font-size", D3C.LINK_TEXT_SIZE + "px")
        .text(link => link.type);
}

function nodeClick(node) {
    if (!d3.event.defaultPrevented) {
		 Appian.Component.saveValue('save',null);
        //only expand/collapse if node contains "Customer" label
        if(node.labels.includes("Customer")) {
            let toExpand = new Set();
            let hasNewExpandedNodes = false; //has new data from api call
            //get a set of all the nodes that can be expanded
            data.rels.forEach(link => {
                if((link.startNode === node.id || link.endNode === node.id) && link.collapsed){
                    toExpand.add(link);
                }
            });

            //TODO: make request
            // //only make api request if a OK response for this node has been made before
            if(!node.hasAllConnections) {
                Requests.getCustomerRelationships(node.properties.customerID, url, clientId, authorization)
                    .then(response => {
						
						if(response.status === 200){
							hasNewExpandedNodes = mergeDataWithGraph(response.data, node, expandLevel);
							
							node.hasAllConnections = true;
						} else {
							return Appian.Component.setValidations("There has been some error retrieving the data. please refresh the page. If problem persists, contact your administrator");
						}
						
						
                        if(toExpand.size > 0) {
                            expandNodes(toExpand, expandLevel);
                        } else if(!hasNewExpandedNodes) { //if there is no existing nodes to expand & no new nodes from api call have been expanded
                            collapseNodes(node);
                        }

                        if(hasNewExpandedNodes) {
                            updateGraph();
                        }
                    })
                    .catch(error => {
                        //error handling
                        console.log(error.message);
						return Appian.Component.setValidations("There has been some error retrieving the data. please refresh the page. If problem persists, contact your administrator");
                    });
            } else {
                if(toExpand.size > 0) {
                    expandNodes(toExpand, expandLevel);
                } else if(!hasNewExpandedNodes) { //if there is no existing nodes to expand & no new nodes from api call have been expanded
                    collapseNodes(node);
                }
            }
        }
    }
}

//expand nodes in a given set
function expandNodes(linkSet, level) {
    linkSet.forEach(link => link.collapsed = false);
    //TODO: make this more dynamic later
    if(level === 2) {
        let linkIds = [...linkSet].map(link => [link.startNode, link.endNode]).reduce((total, current) => new Set([...total, ...current]), new Set());
        data.rels.forEach(link => {
            if(linkIds.has(link.startNode) || linkIds.has(link.endNode)) link.collapsed = false;
        })
    } 
    updateGraph();
}

function collapseNodes(clickedNode) {
    //get a list of connected nodes for each node
    let nodeLinks = [];
    data.rels
        .filter(link => !link.collapsed)
        .forEach(link => {
            if(nodeLinks['id_' + link.source.id] === undefined) {
                nodeLinks['id_' + link.source.id] = [link.target.id];
            } else {
                nodeLinks['id_' + link.source.id].push(link.target.id);
            }

            if(nodeLinks['id_' + link.target.id] === undefined) {
                nodeLinks['id_' + link.target.id] = [link.source.id];
            } else {
                nodeLinks['id_' + link.target.id].push(link.source.id);
            }
        });

    //get list of lengths to get to the root node
    let lengthList = createLengthList(nodeLinks); 

    //filter out all that arent direct links or have a distance to the root less than the clicked node
    let linksToCollapse = data.rels
        .filter(link => { 
            if(link.collapsable) {
                if(link.startNode === clickedNode.id) {
                    return lengthList['id_' + link.endNode] > lengthList['id_' + clickedNode.id];
                } else if (link.endNode === clickedNode.id) {
                    return lengthList['id_' + link.startNode] > lengthList['id_' + clickedNode.id];
                }
            }
            return false;
        });
    
    if(linksToCollapse.length > 0) {
        //collapse directly connected node links
        linksToCollapse.forEach(link => link.collapsed = true); 

        let orphanedNodes = linksToCollapse
            //get connected node ids
            .map(link => link.startNode === clickedNode.id ? link.endNode : link.startNode)
            //get paths for branches that dont go back to the root
            .map(nodeId => {
                let path = [clickedNode.id]; //stores all node ids that branch off of "nodeId"
                let bool = hasPathToRoot(nodeLinks, lengthList, lengthList['id_' + clickedNode.id], nodeId, path);
                //if it has a path back to the root node, set to undefined where it will be filtered out later
                return bool === true ? undefined : path;
            })
            //remove branches that have a path to the root
            .filter(path => path !== undefined)
            //reduce all paths to one set of node ids
            .reduce((total, current) => new Set([...total, ...current]), new Set()); 
        
        //remove the clicked node from the set
        orphanedNodes.delete(clickedNode.id);

        //collapse orphanded nodes
        data.rels.filter(link => link.collapsable).forEach(link => { 
            if(orphanedNodes.has(link.startNode) || orphanedNodes.has(link.endNode)) {
                link.collapsed = true;
            }
        });
    }
    updateGraph();
}

function hasPathToRoot(nodeLinks, lengthList, clickedNodeLength, nodeId, path) {
    //get connected nodes that arent already in the path
    let nodesToSearch = nodeLinks['id_' + nodeId].filter(id => !path.includes(id));

    //if we are at the end of this branch (no path to root found)
    if(nodesToSearch.length === 0) {
        path.push(nodeId);
        return false;
    }
    //check if distance to root node is <= the clicked node (indicates there is another path to the root)
    for(let i = 0; i < nodesToSearch.length; i++) {
        if(lengthList['id_' + nodesToSearch[i]] <= clickedNodeLength) {
            //path to root found
            return true;
        }
    }

    path.push(nodeId);
    //recurively call hasPathToRoot on the current nodes connecting nodes.
    return nodesToSearch
        .map(id => hasPathToRoot(nodeLinks, lengthList, clickedNodeLength, id, path))
        .reduce((total, current) => total || current);;
}

function createLengthList(nodeLinks) {
    let lengthList = [];
    lengthList['id_' + rootId] = 0;
    createLengths(nodeLinks, lengthList, rootId);
    return lengthList;
}

//creates a list of all nodes & their distance to the root node
function createLengths(nodeLinks, lengthList, parentId) {
    let currentLinks = nodeLinks['id_' + parentId];
    let newAdditions = [];
    for(let i = 0; i < currentLinks.length; i++) {
        if(lengthList['id_' + currentLinks[i]] === undefined) {
            lengthList['id_' + currentLinks[i]] = lengthList['id_' + parentId] + 1;
            newAdditions.push(currentLinks[i]); //quicker than calling createLength here.
        }
    }

    newAdditions.forEach(nodeId => createLengths(nodeLinks, lengthList, nodeId));
}

function initialCollapse(graphData, rootNode, level) {
    let levels = [];
    levels[0] = new Set([rootNode.id]);

    //get a list of levels that cannot be collapsed
    for(let i = 0; i < level; i++) {
        levels[i + 1] = new Set();
        graphData.rels.forEach(link => {
            //if link source or target contain the root id
            if(levels[i].has(link.startNode) || levels[i].has(link.endNode)) {
                levels[i + 1].add(link.startNode);
                levels[i + 1].add(link.endNode);
            }
        });
    }

    //set of nodes that cannot be collapsed
    let baseNodes = levels.reduce((total, current) => new Set([...total, ...current]), new Set());

    let hasExpandedNodes = false;
    //links that cannot be collapsed
    graphData.rels.forEach(link => {
        //set collapsed to true if link.source or link.target arent in the set.
        if (!baseNodes.has(link.startNode) || !baseNodes.has(link.endNode)) {
            link.collapsed = true;
            link.collapsable = true;
        } else {
            hasExpandedNodes = true;
            link.collapsed = false;
            link.collapsable = rootNode.id !== rootId;
        }
    });
    return hasExpandedNodes;
}

function populateNodeInfo(node) {
    let keyValues = Object.entries(node.properties);
    
    d3.select('#node-info')
        .selectAll('.node-property')
        .data(keyValues)
        .join(
            enter => createNodeProperty(enter, keyValues.length),
            update => null,
            exit => exit.remove());
}

function depopulateNodeInfo() {
    d3.select('#node-info').selectAll("*").remove();
}

function createNodeProperty(root, keyValuesLength) {
    let widthStr = 'calc(calc(100% - ' + (keyValuesLength + 1) * 10 + 'px) / ' + keyValuesLength + ')';
    let nodePropPadding = 6;
    
    let wrapper = root.append('div').classed('wrapper', true).style('width', widthStr);
    let nodeProperty = wrapper.append('div')
        .classed('node-property', true)
        .style('width', 'calc(100% - ' + nodePropPadding + 'px)')

    //hide the last seperator
    wrapper.append("div").classed('seperator', true)
        .style('visibility', (d, index) => index < keyValuesLength - 1 ? 'visible' : 'hidden');
    
    let wrapperWidth = wrapper.node().getBoundingClientRect().width;
                
    nodeProperty.append('text')
        .classed('property-name', true)
        .text(keyValue => asReadableText(keyValue[0]))
        .each(function() { 
            let textLength = this.getBoundingClientRect().width + (nodePropPadding * 2);
            d3.select(this).style('--distance', () => {
                let length = textLength - wrapperWidth;
                return (length < 0 ? 0 : -length) + "px"
            })
        })

    nodeProperty.append('div')
        .classed('property-value', true)
        .append('text')
            .text(keyValue => keyValue[1])
            .each(function() {
                let textLength = this.getBoundingClientRect().width + (nodePropPadding * 2);
                d3.select(this).style('--distance', () => {
                    let length = textLength - wrapperWidth;
                    return (length < 0 ? 0 : -length) + "px"
                })
            })
}

function asReadableText(variableName) {
    return variableName.replace(/_/g, ' ');
}

function filterExistingData(graphData) {
	
    let nodeIds = data.nodes.map(node => node.id)
        .reduce((total, current) => total.add(current), new Set());
    let filteredNodes = graphData.nodes.filter(node => !nodeIds.has(node.id));

    let linkIds = data.rels.map(link => link.id)
        .reduce((total, current) => total.add(current), new Set());
    let filteredLinks = graphData.rels.filter(link => !linkIds.has(link.startNode + ":" + link.endNode));
	
	if(isProduct){
		filteredLinks = filteredLinks.filter(link => link.type === "HOLDS");
	} else {
		filteredLinks = filteredLinks.filter(link => link.type !== "HOLDS");
	}
	  
    filteredNodes = filteredNodes.filter(node => {
		var linkStartNodeIds = filteredLinks.map(link => link.startNode);
		var linkEndNodeIds = filteredLinks.map(link => link.endNode);
		return ((linkStartNodeIds.includes(node.id)) || (linkEndNodeIds.includes(node.id)))
	});

    
    return { nodes: filteredNodes, rels: filteredLinks };
}